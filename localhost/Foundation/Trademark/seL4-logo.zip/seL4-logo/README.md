<!--
  Copyright seL4 Project a Series of LF Projects, LLC.
  SPDX-License-Identifier: CC-BY-SA-4.0
-->

# seL4 Logo

The seL4 and seL4 Foundation logos.

The logos in this repository are trademark and copyright protected, license
is granted only under the [seL4 trademark guidelines][tm].

[tm]: https://seL4.systems/Foundation/Trademark/